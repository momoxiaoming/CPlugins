package res.gradle.plugin;

/**
 * Constans
 *
 * @author mmxm
 * @date 2021/11/26 14:55
 */
public class Constans
{
    public static String merge_mapping_path="";

    public static String sign_storeFile_path="";
    public static String sign_storePassword="";
    public static String sign_keyAlias="";
    public static String sign_keyPassword="";
}
